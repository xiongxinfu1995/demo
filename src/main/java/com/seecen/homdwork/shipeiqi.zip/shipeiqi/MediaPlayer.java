package com.seecen.homdwork.shipeiqi;

public interface MediaPlayer {
    public void play(String audioType, String fileName);
}
