CREATE VIEW V_TEACHER AS
  SELECT tno,tname,dname FROM
teacher t ,dept d
WHERE t.deptno=d.deptno(+)
/

